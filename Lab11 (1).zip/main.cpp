#include <iostream>
#include <cmath>
using namespace std;


bool ok(int q[], int c);
// void print (int q[]);
void fancyPrint(int q[]);

int main(){
int board[8] = {0}, col = 0;
while(col >= 0){
  if(col > 7){
    fancyPrint(board);
    col--;
    board[col]++;
}
  
if(board[col] > 7){
  board[col] = 0;
  col--;
  if(col != -1) board[col]++;
}
  else if(ok(board, col)){
    col++;
    }
  else {
    board[col]++;
      }
    }
  return 0;
}

bool ok(int q[], int c){
  for(int i = 0; i < c; i++)
    if(q[i] == q[c] || (c-i) == abs(q[c]-q[i]))
      return false;

return true;
}


void fancyPrint(int q[]){
  int i, j, k, l;
  typedef string box[5][7];
  box bb, wb, bq, wq, *board[8][8];

  static int sol = 0;
  sol++;
  cout << "Solution " << sol << ":\n";

  for(int i = 0; i < 5; i++)
    for(int j = 0; j < 7; j++){
      wb[i][j] = " ";
      bq[i][j] = " ";
      bb[i][j] = "\u2585";
      wq[i][j] = "\u2585";
      // wq[i][j] = char(219);
    
    }
    for(i = 0; i <= 3; i++)
      for(j = 1; j <= 5; j++){
        if(i == 3 || j % 2 == 1){
          bq[i][j] = "\u2585";
          wq[i][j] = ' ';
        }
    }
  for(i = 0; i < 8; i++)
    for(j = 0; j < 8; j++)
      if(i == q[j]){
        if((i+j) % 2 == 0) board[i][j] = &bq;
          else board[i][j] = &wq;
      }
      else {
        if((i+j) % 2 == 0) board[i][j] = &wb;
          else board[i][j] = &bb;
      }

    cout << "   ";
    for(i = 0; i < 7*8+1; i++) cout << '_';
      cout << endl;

    for(i = 0; i < 8; i++)
      for(k = 0; k < 5l; k++){
        cout << "    " << "|";
        for(j = 0; j < 8; j++)
          for(l = 0; l < 7; l++)
            cout << (*board[i][j])[k][l];
            cout << '|' << endl;

  
      }
      cout << "    ";
      for(i = 0; i < 7*8+1; i++);
        cout << "\u2585";
        //cout << char(219);
        cout << "|" << endl;
     
}




